window.addEventListener('load', selectyear);
window.addEventListener('load', selectmonth);
window.addEventListener('load', selectdate);

const d = new Date();
function selectyear(){    
    let year =  d.getFullYear()+543;
let element = document.getElementById("year");
let optelement = document.createElement("option");
optelement.value = year;
optelement.innerHTML = year;
element.appendChild(optelement);
}
function selectmonth(){
    $("#month").val(d.getMonth()+1);
}
function selectdate(){
    $("#date").val(d.getDate());
}

function checkyear(){
    let s_idtext = document.getElementById("s_id");

    if (s_idtext.value.length == 10){
        let tmp = s_idtext.value.slice(0,2);
        setyear(tmp);
    }

    if (s_idtext.value.length == 2){
        setyear(s_idtext.value);
    }
}

function setyear(text){
    let fin = (((d.getFullYear()+543)-2500)-text)+1;
    if(fin > 7 || fin < 1){
        $("#s_year").val(1); 
    }
    else{
        $("#s_year").val(fin);
    }
}

var add_total = 0;
var rem_total = 0;

function add_addsubject(){
    let curaddrem = 0;
    if(add_total == 0){
        add_total = 1;
    curaddrem=add_total;}
   else{add_total++;
    curaddrem = add_total;} 
    var table = document.getElementById("addtable");
    var row = table.insertRow();
    var cell1 = row.insertCell();
    var cell2 = row.insertCell();
    var cell3 = row.insertCell();
    var cell4 = row.insertCell();
    var cell5 = row.insertCell();
    var cell6 = row.insertCell();
    var cell7 = row.insertCell();
    var cell8 = row.insertCell();
    var cell9 = row.insertCell();
    cell1.innerHTML = (add_total)+'.';
    cell2.innerHTML = "เพิ่ม";
    cell3.innerHTML = '<input type="text" id="subid_'+add_total+'"'+'name="subid_'+add_total+'" required>';
    cell4.innerHTML = '<input type="text" id="subname_'+add_total+'"'+'name="subname_'+add_total+'" required>';
    cell5.innerHTML = '<input type="text" id="subsec_'+add_total+'"'+'name="subsec_'+add_total+'" required>';
    cell6.innerHTML = '<input type="text" id="subdate_'+add_total+'"'+'name="subdate_'+add_total+'" required>';
    cell7.innerHTML = '<input type="number" id="subw_'+add_total+'"'+'name="subw_'+add_total+'" min="1" max="6" required>';
    cell8.innerHTML = '<input type="text" id="subprofname_'+add_total+'"'+'name="subprofname_'+add_total+'" required>';
    cell9.innerHTML = '<input type="checkbox" id="subprofapprove_'+add_total+'"'+'name="subprofapprove_'+add_total+'"  value="false" disabled required>';
    document.getElementById('addsub').innerHTML = add_total;
}

function remove_addsubject(){
    if(add_total >0){
        document.getElementById("addtable").deleteRow(add_total);
  add_total--;
  document.getElementById('addsub').innerHTML = add_total;

    }

}

function add_remsubject(){
    let curaddrem = 0;
    if(rem_total == 0){
        rem_total = 1;
    curaddrem=rem_total;}
   else{rem_total++;
    curaddrem = rem_total;} 
    var table = document.getElementById("remtable");
    var row = table.insertRow();
    var cell1 = row.insertCell();
    var cell2 = row.insertCell();
    var cell3 = row.insertCell();
    var cell4 = row.insertCell();
    var cell5 = row.insertCell();
    var cell6 = row.insertCell();
    var cell7 = row.insertCell();
    var cell8 = row.insertCell();
    var cell9 = row.insertCell();
    cell1.innerHTML = (rem_total)+'.';
    cell2.innerHTML = "ถอน";
    cell3.innerHTML = '<input type="text" id="subwid_'+rem_total+'"'+'name="subwid_'+rem_total+'" required>';
    cell4.innerHTML = '<input type="text" id="subwname_'+rem_total+'"'+'name="subwname_'+rem_total+'" required>';
    cell5.innerHTML = '<input type="text" id="subwsec_'+rem_total+'"'+'name="subwsec_'+rem_total+'" required>';
    cell6.innerHTML = '<input type="text" id="subwdate_'+rem_total+'"'+'name="subwdate_'+rem_total+'" required>';
    cell7.innerHTML = '<input type="number" id="subww_'+rem_total+'"'+'name="subww_'+rem_total+'" min="1" max="6" required>';
    cell8.innerHTML = '<input type="text" id="subwprofname_'+rem_total+'"'+'name="subwprofname_'+rem_total+'" required>';
    cell9.innerHTML = '<input type="checkbox" id="subwprofapprove_'+rem_total+'"'+'name="subwprofapprove_'+rem_total+'"  value="false" disabled required>';
    document.getElementById('removesub').innerHTML = rem_total;
}

function remove_remsubject(){
    if(rem_total>0){
        document.getElementById("remtable").deleteRow(rem_total);
        rem_total--;
        document.getElementById('removesub').innerHTML = rem_total;

    }
}





function validateForm() {
    
if(add_total+rem_total == 0 ){
    alert("กรุณากรอกรายละเอียดเพิ่มถอนรายวิชา");
            return false;
} 
   
    let s_id = document.forms["Form"]["s_id"].value;
        if(isNaN(s_id)==true){
            alert("กรุณากรอกเลขทะเบียนให้ถูกต้องซึ่งเป็นตัวเลขทั้งหมด เช่น:6312345678");
            return false;}
        
        if(s_id.length != 10){
            alert("กรุณากรอกเลขทะเบียนให้ถูกต้องและต้องเป็นตัวเลข 10 หลัก  เช่น:6312345678");
            return false;
        }  
    

    
    let post_code = document.forms["Form"]["post_code"].value;
    if(isNaN(post_code)==true){
        alert("กรุณากรอกหัสไปรษณีย์ให้ถูกต้องซึ่งเป็นตัวเลขทั้งหมด เช่น:12121");
        return false;}
    
    if(post_code.length != 5){
        alert("กรุณากรอกรหัสไปรษณีย์ให้ถูกต้องและต้องเป็นตัวเลข 5 หลัก  เช่น:12121");
        return false;
    }  

    let mobile_phone = document.forms["Form"]["mobile_phone"].value;
    if(isNaN(mobile_phone)==true){
        alert("กรุณากรอกเบอร์โทรศัพท์มือถือให้ถูกต้องซึ่งเป็นตัวเลขทั้งหมด เช่น:0812345678");
        return false;}
    if(mobile_phone.length != 10){
            alert("กรุณากรอกเบอร์โทรศัพท์มือถือให้ถูกต้องและต้องซึ่งเป็นตัวเลข 10 หลัก เช่น:0812345678");
            return false;
        }  
        if(mobile_phone.charAt(0) != '0'){
            alert("กรุณากรอกเบอร์โทรศัพท์มือถือให้ถูกต้องและต้องซึ่งขึ้นต้นด้วย 0 เช่น:0812345678");
            return false;
        }  

    let home_phone = document.forms["Form"]["home_phone"].value;
    if(home_phone != ""){
        if(isNaN(home_phone)==true){
            alert("กรุณากรอกเบอร์โทรศัพท์บ้านให้ถูกต้องซึ่งเป็นตัวเลขทั้งหมด เช่น:021234567,0123456789");
            return false;}
        if(home_phone.charAt(0) == '0' &&home_phone.charAt(1)== '1'&& home_phone.length != 10){
            alert("กรุณากรอกเบอร์โทรศัพท์บ้านให้ถูกต้องและต้อง หากขึ้นต้นด้วย 01 จะต้องเป็นตัวเลข 10 หลัก เช่น:0123456789");
        return false;
        }else{
            if(home_phone.length != 9 && home_phone.charAt(1)!= '1'){
                alert("กรุณากรอกเบอร์โทรศัพท์บ้านให้ถูกต้องและต้องซึ่งเป็นตัวเลข 9 หลัก เช่น:021234567");
                return false;
            }  
            if(home_phone.charAt(0) != '0'){
                alert("กรุณากรอกเบอร์โทรศัพท์บ้านให้ถูกต้องและต้องซึ่งขึ้นต้นด้วย 0 เช่น:021234567");
                return false;
            }  


        }
        

    }


   alert("ส่งข้อมูลเรียบร้อย");
   conslog()
   return false; //  preventing page refreshing when submit
  }




function conslog(){
   
    let year =document.forms["Form"]["year"].value; 
    let month = document.forms["Form"]["month"].value; 
    let date = document.forms["Form"]["date"].value; 
    let n_date = year+'-'+month+'-'+date;
    let name = document.forms["Form"]["fname"].value; 
    let sid = document.forms["Form"]["s_id"].value; 
    let syear = document.forms["Form"]["s_year"].value; 
    let surname = document.forms["Form"]["lname"].value ;
    let field = document.forms["Form"]["major"].value ;
    let advisor = document.forms["Form"]["advisor"].value ; 
    let address_num = document.forms["Form"]["h_num"].value ; 
    let moo = document.forms["Form"]["moo"].value ; 
    let tumbol = document.forms["Form"]["s_district"].value ; 
    let amphur = document.forms["Form"]["district"].value ;
    let mobilephone = document.forms["Form"]["mobile_phone"].value ;
    let phone = document.forms["Form"]["home_phone"].value ; 
    let province = document.forms["Form"]["province"].value ;
    let postcode = document.forms["Form"]["post_code"].value ;
    let cause = document.forms["Form"]["reason"].value ;
    let text = '{ \n  "date": "'+n_date+'",\n  "studentFirstName": "'+name+'",\n  "studentLastName": "'+surname+'",\n  "studentId": "'+sid+'",\n  "studentYear": '+syear+',\n  "studyField": "'+field+'",\n  "advisor": "'+advisor+'",\n  "addressNumber": "'+address_num+'",\n  "moo": "'+moo+'",\n  "tumbol": "'+tumbol+'",\n  "amphur": "'+amphur+'",\n  "province": "'+province+'",\n  "postCode": "'+postcode+'",\n  "mobilePhone": "'+mobilephone+'",\n  "phone": "'+phone+'",\n  "cause": "'+cause+'",';
    
    
    if(add_total > 0){
        let textadd = '\n  "addSubjectList": [';
        for (let i = 1; i <= add_total; i++) {
            let idtmp = document.getElementById(('subid_'+i));
            let nametmp = document.getElementById(('subname_'+i));
            let sectmp = document.getElementById(('subsec_'+i));
            let datetmp = document.getElementById(('subdate_'+i));
            let nuaitmp = document.getElementById(('subw_'+i));
            let proftmp = document.getElementById(('subprofname_'+i));
            let appovetmp = document.getElementById(('subprofapprove_'+i));
            let tmp = '  \n    {\n\t'+'  "subjectCode": "'+idtmp.value+'",\n\t  "subjectName": "'+nametmp.value+'",\n\t  "subjectSection": "'+sectmp.value+'",\n\t  "subjectDate": "'+datetmp.value+'",\n\t  "subjectCredit": "'+nuaitmp.value+'",\n\t  "subjectTeacher": "'+proftmp.value+'",\n\t  "subjectTeacherCheck": '+appovetmp.value+'\n    }';
            if(i < add_total){ tmp =tmp+',' }
            if(i == add_total && rem_total == 0){ tmp =tmp+'\n  ]' }
            if(i == add_total && rem_total != 0){ tmp =tmp+'\n  ],' }
            textadd = textadd+tmp;
           
          }
          text = text+textadd;
    }
    

    if(rem_total > 0){
        let textrem = '\n  "dropSubjectList": [';
        for (let i = 1; i <= rem_total; i++) {
            let idtmp = document.getElementById(('subwid_'+i));
            let nametmp = document.getElementById(('subwname_'+i));
            let sectmp = document.getElementById(('subwsec_'+i));
            let datetmp = document.getElementById(('subwdate_'+i));
            let nuaitmp = document.getElementById(('subww_'+i));
            let proftmp = document.getElementById(('subwprofname_'+i));
            let appovetmp = document.getElementById(('subwprofapprove_'+i));
            let tmp = '  \n    {\n\t'+'  "subjectCode": "'+idtmp.value+'",\n\t  "subjectName": "'+nametmp.value+'",\n\t  "subjectSection": "'+sectmp.value+'",\n\t  "subjectDate": "'+datetmp.value+'",\n\t  "subjectCredit": "'+nuaitmp.value+'",\n\t  "subjectTeacher": "'+proftmp.value+'",\n\t  "subjectTeacherCheck": '+appovetmp.value+'\n    }';
            if(i < rem_total){ tmp =tmp+',' }
            if(i == rem_total){ tmp =tmp+'\n  ]' }
            textrem = textrem+tmp;
           
          }
          text = text+textrem;
    }
    
    text = text+'\n}';
    console.log(text);
 
}