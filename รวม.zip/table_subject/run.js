var http = require('http');
var fs = require('fs');
var os = require("os");
http.createServer(function (req, res) {
  console.log(req.url);
  //console.log(req);
  if(req.method === 'GET'){
    var url = '';
    var index = req.url.indexOf('?');
    var path;
    if(index != -1)
      path = req.url.substring(0,index);
    else
      path = req.url;
    console.log('path: ' + path);
    switch(path){
      case '/student-main':
          url = 'html/student-main.html';
          break;
      case '/getStudent_Subject':
          url = 'res/student_subject.json';
          break;
      case '/getreg_subject':
            url = 'res/reg_subject.json';
            break;
      case '/student-main':
          url = 'html/student-main.html';
          break;
      case '/logintemp':
            url = 'html/login.html';
            break;
      case '/gettest_table':
            url = 'res/test.json';
            break;
      case '/edit_class_table':
          url = 'html/edit_class_table.html';
          break;
      case '/edit_grade':
          url = 'html/edit_grade.html';
          break;
      case '/class_table':
          url = 'html/class_table.html';
            break;
            case '/fiilldocument':
          url = 'html/forminput.html';
            break;
            case '/studentstatus':
          url = 'html/student_status.html';
            break;
            case '/digitalsig':
              url = 'html/u3_digital.html';
                break;
                case '/search':
                  url = 'html/search.html';
                  break;
              case '/getStudent':
                  url = 'res/student.json';
                  break;
              case '/info':
                  url = 'html/info.html';
                  break;
                  case '/edit_information':
                  url = 'html/add_moreinformation.html';
                  break;



      case '/exit':
          process.exit();
          break;
      default:
          if(req.url.includes('.')){
            url = req.url;
            break;
          }
          url = 'html/redirect.html';
          break;
      }

      console.log(url);
      if(url){
        if(url.charAt(0) == '/'){
          url = url.substring(1);
        }
        fs.readFile(url, function(err, data) {
        
            console.log(err);
            if(err){
              res.writeHead(404, {'Content-Type': 'text/html'});
              res.write('<h1>404 NOT FOUND</h1>');
              return res.end();
            }else{
              if(url.endsWith('.html'))
                res.writeHead(200, {'Content-Type': 'text/html'});
              else if(url.endsWith('.js')){
                res.writeHead(200, {'Content-Type': 'text/javascript'});
              }else if(url.endsWith('.json')){
                res.writeHead(200, {'Content-Type': 'application/json'});
              }else{
                res.writeHead(200, {'Content-Type': 'text/plain'});
              }
              res.write(data);
              return res.end();
            }
        });
      }else{
        res.end();
      } 
    } else if(req.method === 'POST'){
      var url = '';
      var index = req.url.indexOf('?');
      var path;
      if (index != -1){
        path = req.url.substring(0,index);
        
      }else{
        path = req.url;
      }
      console.log('path: '+path);
      switch(path){
        case '/saveStudent':
          req.on('data',chunk =>{
            let json = JSON.parse(chunk);

            

            let outputJSON = [];
            let data = fs.readFileSync('res/student_subject.json',{encoding:'utf8',flag:'r'});
            outputJSON=JSON.parse(data);
            outputJSON.push(json);
            outputJSON=JSON.stringify(outputJSON);
            fs.writeFileSync('res/student_subject.json',outputJSON)
            res.writeHead(200,{'Content-Type':'text/plain'});
            res.write('OK');
            res.end();
          });
          break;

          case '/saveStudentform':
          req.on('data',chunk =>{
            let json = JSON.parse(chunk);
            let outputJSON = [];
            let data = fs.readFileSync('res/studentformrequested.json',{encoding:'utf8',flag:'r'});
            outputJSON=JSON.parse(data);
            outputJSON.push(json);
            outputJSON=JSON.stringify(outputJSON);
            fs.writeFileSync('res/studentformrequested.json',outputJSON)
            res.writeHead(200,{'Content-Type':'text/plain'});
            res.write('OK');
            res.end();
          })
      break;
          
      }
      



    }
    
    
    
    
    
    
    
    
    
    else{
      res.end();
    }


}).listen(8080);

