const express = require('express')
const app = express()
const members = require('res/member.json')
const bodyParser = require('body-parser')

app.get('/',(req,res) =>{
    res.send('hello')
})

app.get('/member',(req,res) =>{
    res.json(members)
})

app.listen(4200,() => {
    console.log('start server at port 4200')
})

