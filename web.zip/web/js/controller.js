window.addEventListener('load', selectyear);
window.addEventListener('load', selectmonth);
window.addEventListener('load', selectdate);
window.addEventListener('load',formatAMPM);
window.addEventListener('load',selectid);

const d = new Date();
function selectyear(){    
    let year =  d.getFullYear()+543;
let element = document.getElementById("year");
let optelement = document.createElement("option");
optelement.value = year;
optelement.innerHTML = year;
element.appendChild(optelement);
}
function selectmonth(){
    $("#month").val(d.getMonth()+1);
}
function selectdate(){
    $("#date").val(d.getDate());
    
}

function selectid(){
    let tmpid = getParameterByName('id'); 
    
    $("#s_id").val(tmpid);
    checkyear()
}

function checkyear(){
    let s_idtext = document.getElementById("s_id");

    if (s_idtext.value.length == 10){
        let tmp = s_idtext.value.slice(0,2);
        setyear(tmp);
    }

    if (s_idtext.value.length == 2){
        setyear(s_idtext.value);
    }
}


function setyear(text){
    let fin = (((d.getFullYear()+543)-2500)-text)+1;
    if(fin > 7 || fin < 1){
        $("#s_year").val(1); 
    }
    else{
        $("#s_year").val(fin);
    }
}

var add_total = 0;
var rem_total = 0;

function add_addsubject(){
    let curaddrem = 0;
    if(add_total == 0){
        add_total = 1;
    curaddrem=add_total;}
   else{add_total++;
    curaddrem = add_total;} 
    var table = document.getElementById("addtable");
    var row = table.insertRow();
    var cell1 = row.insertCell();
    var cell2 = row.insertCell();
    var cell3 = row.insertCell();
    var cell4 = row.insertCell();
    var cell5 = row.insertCell();
    var cell6 = row.insertCell();
    var cell7 = row.insertCell();
    var cell8 = row.insertCell();
    var cell9 = row.insertCell();
    cell1.innerHTML = (add_total)+'.';
    cell2.innerHTML = "เพิ่ม";
    cell3.innerHTML = '<input type="text" id="subid_'+add_total+'"'+'name="subid_'+add_total+'" required>';
    cell4.innerHTML = '<input type="text" id="subname_'+add_total+'"'+'name="subname_'+add_total+'" required>';
    cell5.innerHTML = '<input type="text" id="subsec_'+add_total+'"'+'name="subsec_'+add_total+'" required>';
    cell6.innerHTML = '<input type="text" id="subdate_'+add_total+'"'+'name="subdate_'+add_total+'" required>';
    cell7.innerHTML = '<input type="number" id="subw_'+add_total+'"'+'name="subw_'+add_total+'" min="1" max="6" required>';
    cell8.innerHTML = '<input type="text" id="subprofname_'+add_total+'"'+'name="subprofname_'+add_total+'" required>';
    cell9.innerHTML = '<input type="checkbox" id="subprofapprove_'+add_total+'"'+'name="subprofapprove_'+add_total+'"  value="false" disabled required>';
    document.getElementById('addsub').innerHTML = add_total;
}

function remove_addsubject(){
    if(add_total >0){
        document.getElementById("addtable").deleteRow(add_total);
  add_total--;
  document.getElementById('addsub').innerHTML = add_total;

    }

}

function add_remsubject(){
    let curaddrem = 0;
    if(rem_total == 0){
        rem_total = 1;
    curaddrem=rem_total;}
   else{rem_total++;
    curaddrem = rem_total;} 
    var table = document.getElementById("remtable");
    var row = table.insertRow();
    var cell1 = row.insertCell();
    var cell2 = row.insertCell();
    var cell3 = row.insertCell();
    var cell4 = row.insertCell();
    var cell5 = row.insertCell();
    var cell6 = row.insertCell();
    var cell7 = row.insertCell();
    var cell8 = row.insertCell();
    var cell9 = row.insertCell();
    cell1.innerHTML = (rem_total)+'.';
    cell2.innerHTML = "ถอน";
    cell3.innerHTML = '<input type="text" id="subwid_'+rem_total+'"'+'name="subwid_'+rem_total+'" required>';
    cell4.innerHTML = '<input type="text" id="subwname_'+rem_total+'"'+'name="subwname_'+rem_total+'" required>';
    cell5.innerHTML = '<input type="text" id="subwsec_'+rem_total+'"'+'name="subwsec_'+rem_total+'" required>';
    cell6.innerHTML = '<input type="text" id="subwdate_'+rem_total+'"'+'name="subwdate_'+rem_total+'" required>';
    cell7.innerHTML = '<input type="number" id="subww_'+rem_total+'"'+'name="subww_'+rem_total+'" min="1" max="6" required>';
    cell8.innerHTML = '<input type="text" id="subwprofname_'+rem_total+'"'+'name="subwprofname_'+rem_total+'" required>';
    cell9.innerHTML = '<input type="checkbox" id="subwprofapprove_'+rem_total+'"'+'name="subwprofapprove_'+rem_total+'"  value="false" disabled required>';
    document.getElementById('removesub').innerHTML = rem_total;
}

function remove_remsubject(){
    if(rem_total>0){
        document.getElementById("remtable").deleteRow(rem_total);
        rem_total--;
        document.getElementById('removesub').innerHTML = rem_total;

    }
}



function c_chackfname(){
    let c_fname = document.forms["Form"]["fname"].value;
    if((isNaN(c_fname)==false )&& (c_fname.length != 0)){
        alert("กรุณากรอกชื่อจริงให้ถูกต้องซึ่งเป็นตัวอักษรทั้งหมด");
        }
}


function c_chacklname(){
    let c_lname = document.forms["Form"]["lname"].value;
    if((isNaN(c_lname)==false) && (c_lname.length != 0) ){
        alert("กรุณากรอกนามสกุลให้ถูกต้องซึ่งเป็นตัวอักษรทั้งหมด");
        }
}


function c_chackid(){
    let c_id = document.forms["Form"]["s_id"].value;
    if((isNaN(c_id)==true) && (c_id.length != 0) ){
        alert("กรุณากรอกเลขทะเบียนให้ถูกต้องซึ่งเป็นตัวเลขทั้งหมด เช่น:6312345678");
        }
    
        if((c_id.length != 0)){
            if((c_id.length != 10) ){
                alert("กรุณากรอกเลขทะเบียนให้ถูกต้องและต้องเป็นตัวเลข 10 หลัก  เช่น:6312345678");
               
            }  

        }
   
}

function c_chackmajor(){
    let c_major = document.forms["Form"]["major"].value;
    if((isNaN(c_major)==false) && (c_major.length != 0) ){
        alert("กรุณากรอกสาขาวิชาให้ถูกต้องซึ่งเป็นตัวอักษรทั้งหมด");
        }

}

function c_chackadvisor(){

    let c_advisor = document.forms["Form"]["advisor"].value;
    if((isNaN(c_advisor)==false) && (c_advisor.length != 0) ){
        alert("กรุณากรอกอาจารย์ที่ปรึกษาให้ถูกต้องซึ่งเป็นตัวอักษรทั้งหมด");
        }
}

function c_chackpost(){
  
    let c_postcode = document.forms["Form"]["post_code"].value;
    if((isNaN(c_postcode)==true)  || (c_postcode.length != 5) ){
        alert("กรุณากรอกหัสไปรษณีย์ให้ถูกต้องซึ่งเป็นตัวเลข และต้องเป็นตัวเลข 5 หลัก เช่น:12121");
       }

}

function c_chackphone(){

    let c_mobile_phone = document.forms["Form"]["mobile_phone"].value;
    if(isNaN(c_mobile_phone)==true){
        alert("กรุณากรอกเบอร์โทรศัพท์มือถือให้ถูกต้องซึ่งเป็นตัวเลขทั้งหมด เช่น:0812345678");
        }
    if(c_mobile_phone.length != 10){
            alert("กรุณากรอกเบอร์โทรศัพท์มือถือให้ถูกต้องและต้องซึ่งเป็นตัวเลข 10 หลัก เช่น:0812345678");
         
        }  
        if(c_mobile_phone.charAt(0) != '0'){
            alert("กรุณากรอกเบอร์โทรศัพท์มือถือให้ถูกต้องและต้องซึ่งขึ้นต้นด้วย 0 เช่น:0812345678");
           
        }  

}

function c_chackhomephone(){
    let c_home_phone = document.forms["Form"]["home_phone"].value;
    if(c_home_phone.length != 0){

        if(isNaN(c_home_phone)==true){
            alert("กรุณากรอกเบอร์โทรศัพท์บ้านให้ถูกต้องซึ่งเป็นตัวเลขทั้งหมด เช่น:021234567,0123456789");
            return false;}
        if(c_home_phone.charAt(0) == '0' &&c_home_phone.charAt(1)== '1'&& c_home_phone.length != 10){
            alert("กรุณากรอกเบอร์โทรศัพท์บ้านให้ถูกต้องและต้อง หากขึ้นต้นด้วย 01 จะต้องเป็นตัวเลข 10 หลัก เช่น:0123456789");
        return false;
        }else{
            if(c_home_phone.length != 9 && c_home_phone.charAt(1)!= '1'){
                alert("กรุณากรอกเบอร์โทรศัพท์บ้านให้ถูกต้องและต้องซึ่งเป็นตัวเลข 9 หลัก เช่น:021234567");
                return false;
            }  
            if(c_home_phone.charAt(0) != '0'){
                alert("กรุณากรอกเบอร์โทรศัพท์บ้านให้ถูกต้องและต้องซึ่งขึ้นต้นด้วย 0 เช่น:021234567");
                return false;
            }  


        }

        
    }  


}


function validateForm() {
    
let c_fname = document.forms["Form"]["fname"].value;
    if((isNaN(c_fname)==false )&& (c_fname.length != 0)){
        alert("กรุณากรอกชื่อจริงให้ถูกต้องซึ่งเป็นตัวอักษรทั้งหมด");
        return false;
        }

        let c_lname = document.forms["Form"]["lname"].value;
        if((isNaN(c_lname)==false) && (c_lname.length != 0) ){
            alert("กรุณากรอกนามสกุลให้ถูกต้องซึ่งเป็นตัวอักษรทั้งหมด");
            return false;
            }

            let c_major = document.forms["Form"]["major"].value;
            if((isNaN(c_major)==false) && (c_major.length != 0) ){
                alert("กรุณากรอกสาขาวิชาให้ถูกต้องซึ่งเป็นตัวอักษรทั้งหมด");
                return false;
                }

                let c_advisor = document.forms["Form"]["advisor"].value;
                if((isNaN(c_advisor)==false) && (c_advisor.length != 0) ){
                    alert("กรุณากรอกอาจารย์ที่ปรึกษาให้ถูกต้องซึ่งเป็นตัวอักษรทั้งหมด");
                    return false;
                    }
   
    let s_id = document.forms["Form"]["s_id"].value;
        if(isNaN(s_id)==true){
            alert("กรุณากรอกเลขทะเบียนให้ถูกต้องซึ่งเป็นตัวเลขทั้งหมด เช่น:6312345678");
            return false;}
        
        if(s_id.length != 10){
            alert("กรุณากรอกเลขทะเบียนให้ถูกต้องและต้องเป็นตัวเลข 10 หลัก  เช่น:6312345678");
            return false;
        }  
        
    let post_code = document.forms["Form"]["post_code"].value;
    if(isNaN(post_code)==true){
        alert("กรุณากรอกหัสไปรษณีย์ให้ถูกต้องซึ่งเป็นตัวเลขทั้งหมด เช่น:12121");
        return false;}
    
    if(post_code.length != 5){
        alert("กรุณากรอกรหัสไปรษณีย์ให้ถูกต้องและต้องเป็นตัวเลข 5 หลัก  เช่น:12121");
        return false;
    }  

    let mobile_phone = document.forms["Form"]["mobile_phone"].value;
    if(isNaN(mobile_phone)==true){
        alert("กรุณากรอกเบอร์โทรศัพท์มือถือให้ถูกต้องซึ่งเป็นตัวเลขทั้งหมด เช่น:0812345678");
        return false;}
    if(mobile_phone.length != 10){
            alert("กรุณากรอกเบอร์โทรศัพท์มือถือให้ถูกต้องและต้องซึ่งเป็นตัวเลข 10 หลัก เช่น:0812345678");
            return false;
        }  
        if(mobile_phone.charAt(0) != '0'){
            alert("กรุณากรอกเบอร์โทรศัพท์มือถือให้ถูกต้องและต้องซึ่งขึ้นต้นด้วย 0 เช่น:0812345678");
            return false;
        }  

    let home_phone = document.forms["Form"]["home_phone"].value;
    if(home_phone != ""){
        if(isNaN(home_phone)==true){
            alert("กรุณากรอกเบอร์โทรศัพท์บ้านให้ถูกต้องซึ่งเป็นตัวเลขทั้งหมด เช่น:021234567,0123456789");
            return false;}
        if(home_phone.charAt(0) == '0' &&home_phone.charAt(1)== '1'&& home_phone.length != 10){
            alert("กรุณากรอกเบอร์โทรศัพท์บ้านให้ถูกต้องและต้อง หากขึ้นต้นด้วย 01 จะต้องเป็นตัวเลข 10 หลัก เช่น:0123456789");
        return false;
        }else{
            if(home_phone.length != 9 && home_phone.charAt(1)!= '1'){
                alert("กรุณากรอกเบอร์โทรศัพท์บ้านให้ถูกต้องและต้องซึ่งเป็นตัวเลข 9 หลัก เช่น:021234567");
                return false;
            }  
            if(home_phone.charAt(0) != '0'){
                alert("กรุณากรอกเบอร์โทรศัพท์บ้านให้ถูกต้องและต้องซึ่งขึ้นต้นด้วย 0 เช่น:021234567");
                return false;
            }  


        }
        

    }


   alert("ส่งข้อมูลเรียบร้อย");
   conslog()
   return false; //  preventing page refreshing when submit
  }


function conslog(){
   
    let year =document.forms["Form"]["year"].value; 
    let month = document.forms["Form"]["month"].value; 
    let date = document.forms["Form"]["date"].value; 
    let n_date = year+'-'+month+'-'+date;


    var json = {
        "date":n_date,"studentFirstName":document.forms["Form"]["fname"].value,"studentLastName":document.forms["Form"]["lname"].value,
         "studentId":document.forms["Form"]["s_id"].value,"studentYear":document.forms["Form"]["s_year"].value,"studyField":document.forms["Form"]["major"].value,
        "advisor":document.forms["Form"]["advisor"].value,"address_num":document.forms["Form"]["h_num"].value,"moo": document.forms["Form"]["moo"].value,
        "tumbol":document.forms["Form"]["s_district"].value,"amphur":document.forms["Form"]["district"].value,"mobilephone":document.forms["Form"]["mobile_phone"].value,
        "phone": document.forms["Form"]["home_phone"].value,"province":document.forms["Form"]["province"].value,"postcode":document.forms["Form"]["post_code"].value,
        "cause":document.forms["Form"]["reason"].value,"sub_addORrem":document.getElementById("subaddrem").value,"subid": document.getElementById("subid").value,
        "subname":document.getElementById("subname").value,"subsec":document.getElementById("subsec").value,"subdate":document.getElementById("subdate").value,
        "subweight":document.getElementById("subw").value,"subprofname":document.getElementById("subprofname").value,"teacheradvisorcheck":false,"teacheradvisorapprove":false,
        "teachersubjectcheck":false,"teachersubjectapprove":false,"authorcheck":false,"authorapprove":false,"teacheradvisorcomment":"","teachersubjectcomment":"","authorcomment":""

    };
  
//let text = '{"date": "'+n_date+'", "studentFirstName": "'+name+'", "studentLastName": "'+surname+'",  "studentId": "'+sid+'", "studentYear": '+syear+', "studyField": "'+field+'", "advisor": "'+advisor+'", "addressNumber": "'+address_num+'", "moo": "'+moo+'", "tumbol": "'+tumbol+'", "amphur": "'+amphur+'", "province": "'+province+'", "postCode": "'+postcode+'",  "mobilePhone": "'+mobilephone+'", "phone": "'+phone+'",  "cause": "'+cause+'",';
//let tmp = '"addSubjectList": ['+'{'+'  "subjectCode": "'+idtmp.value+'","subjectName": "'+nametmp.value+'","subjectSection": "'+sectmp.value+'","subjectDate": "'+datetmp.value+'", "subjectCredit": "'+nuaitmp.value+'","subjectTeacher": "'+proftmp.value+'", "addorrem": '+addorrem.value+'   }';
        
var myJSON = JSON.stringify(json);
const xhttp = new XMLHttpRequest();
xhttp.onload = function(){
    let msg = this.responseText;
    alert(msg);
};
xhttp.open("POST", "/saveStudentform");
xhttp.send(myJSON);
 
}




function saveFile(text){
  //  var myJSON = JSON.stringify(text);
    const xhttp = new XMLHttpRequest();
    xhttp.onload=function(){
        let msg = this.responseText;
        //alert(msg);
    };
    xhttp.open("POST","/saveStudentform");
    xhttp.send(myJSON);


 }



function getParameterByName(name, url = window.location.href) {
    name = name.replace(/[\[\]]/g, '\\$&');
     var regex = new RegExp('[?&]' + name + '(=([^&#]*)|&|#|$)'),
         results = regex.exec(url);
     if (!results) return null;
     if (!results[2]) return '';
     return decodeURIComponent(results[2].replace(/\+/g, ' '));
 }

function clickeditclass(){
    let tmpid = getParameterByName('id');   
    window.location.replace ("edit_class_table?id="+tmpid) ;
 }
 function clickclasstable(){
    let tmpid = getParameterByName('id');   
    window.location.replace ("/class_table?id="+tmpid) ;
 }
 function clickeditgrade(){
    let tmpid = getParameterByName('id');   
    window.location.replace ("/edit_grade?id="+tmpid) ;
 }

 function clickfilldoc(){
    let tmpid = getParameterByName('id'); 
    window.location.replace ("/fiilldocument?id="+tmpid); 
 }

 function clickstudentstatus(){
    let tmpid = getParameterByName('id'); 
    window.location.replace ("/studentstatus?id="+tmpid);

 }
 function clickstudentmain(){
    let tmpid = getParameterByName('id'); 
    let tmpname = getParameterByName('name'); 
    if(tmpname==null){
        tmpname =" ";
    }
    window.location.replace ("/student-main?id="+tmpid+"&name="+tmpname);
 }

 function signout(){
    window.location.replace ("/logintemp");
 }

 function clickinformation(){
    let tmpid = getParameterByName('id'); 
    window.location.replace ("/edit_information?id="+tmpid);
 }


 function formatAMPM() {
    
    var d = new Date();
        months = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];
        
        document.getElementById("para1").innerHTML = ' '+months[d.getMonth()]+' '+d.getDate()+' '+d.getFullYear()+' ';
    }
    
    function dropd(){
        var dropdown = document.getElementsByClassName("dropdown-btn");
        var i;
        
        for (i = 0; i < dropdown.length; i++) {
          dropdown[i].addEventListener("click", function() {
          this.classList.toggle("active");
          var dropdownContent = this.nextElementSibling;
          if (dropdownContent.style.display === "block") {
          dropdownContent.style.display = "none";
          } else {
          dropdownContent.style.display = "block";
          }
          });
        }
    }